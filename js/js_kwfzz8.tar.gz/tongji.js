var code = '<src="https://s22.cnzz.com/z_stat.php?id=1271023179&web_id=1271023179" language="JavaScript"></script>';

document.write('<div style="display:none;">' + code + '</div>');